package com.parmeshl.weather.dto;

public class Weather {
private String main;

public String getMain() {
	return main;
}

public void setMain(String main) {
	this.main = main;
}

}
