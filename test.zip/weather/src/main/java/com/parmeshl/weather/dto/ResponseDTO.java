package com.parmeshl.weather.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponseDTO implements Serializable {

	private static final long serialVersionUID = 5763148931413501367L;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonProperty("dt_txt")
	private LocalDateTime dt;
	
	private BigDecimal minTemp;

	private BigDecimal maxTemp;
	
	private String advice;

	public LocalDateTime getDate() {
		return dt;
	}

	public void setDate(LocalDateTime date) {
		this.dt = date;
	}

	public BigDecimal getMinTemp() {
		return minTemp;
	}

	public void setMinTemp(BigDecimal minTemp) {
		this.minTemp = minTemp;
	}

	public BigDecimal getMaxTemp() {
		return maxTemp;
	}

	public void setMaxTemp(BigDecimal maxTemp) {
		this.maxTemp = maxTemp;
	}

	public String getAdvice() {
		return advice;
	}

	public void setAdvice(String advice) {
		this.advice = advice;
	}
	
}
