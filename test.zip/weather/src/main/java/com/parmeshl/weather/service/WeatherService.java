package com.parmeshl.weather.service;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.alicp.jetcache.anno.Cached;
import com.parmeshl.weather.dto.ResponseDTO;
import com.parmeshl.weather.dto.WeatherMapDTO;
import com.parmeshl.weather.dto.WeatherMapTimeDTO;

import springfox.documentation.spring.web.json.Json;

@Service
public class WeatherService {

	private final String URI = "https://samples.openweathermap.org/data/2.5/forecast";
	private final String API_ID = "d29292e9483efc82c82c32ee7%20e02d563e";

	private final RestTemplate restTemplate;

	public WeatherService(RestTemplateBuilder restTemplateBuilder) {
		this.restTemplate = restTemplateBuilder.build();
	}

	@Cached(expire = 10, timeUnit = TimeUnit.MINUTES)
	public ResponseEntity<?> weatherForecastAverage(String city) {
		List<ResponseDTO> result = new ArrayList<ResponseDTO>();
		try {
			WeatherMapDTO weatherMap = this.restTemplate.getForObject(this.url(city), WeatherMapDTO.class);
			for (LocalDate reference = LocalDate.now(); reference
					.isBefore(LocalDate.now().plusDays(3)); reference = reference.plusDays(1)) {
				final LocalDate ref = reference;
				List<WeatherMapTimeDTO> collect = weatherMap.getList().stream()
						.filter(x -> x.getDt().toLocalDate().equals(ref)).collect(Collectors.toList());
				if (!CollectionUtils.isEmpty(collect)) {
					result.add(this.average(collect));
				}

			}
		} catch (HttpClientErrorException e) {
			return new ResponseEntity<>(new Json(e.getResponseBodyAsString()), e.getStatusCode());
		}

		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	private ResponseDTO average(List<WeatherMapTimeDTO> list) {
		ResponseDTO resDto = new ResponseDTO();
		for (WeatherMapTimeDTO item : list) {
			resDto.setDate(item.getDt());
			resDto.setMaxTemp(item.getMain().getTemp_max());
			resDto.setMinTemp(item.getMain().getTemp_min());
			String advice = "";
			DecimalFormat deciFormat = new DecimalFormat();
			deciFormat.setParseBigDecimal(true);

			System.out.println(deciFormat.isParseBigDecimal());

			if (item.getMain().getTemp_max().intValue() > 40) {
				advice = "Use sun screen lotion";
			}

			if (item.getWeather().get(0).getMain().contentEquals("Rain")) {
				if (!advice.contentEquals("")) {
					advice = advice + " and Carry umbrella";
				} else {
					advice = "Carry umbrella";
				}
			}

			resDto.setAdvice(advice);
		}
		return resDto;
	}

	private String url(String city) {
		return String.format(URI.concat("?q=%s").concat("&appid=%s"), city, API_ID);
	}

}
